# control.py
import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from aster import (
    AsterServer, service, rpc, server_stream, client_stream, bidi_stream, wire_type,
)

# ─────────────── Wire types ───────────────

@wire_type("mission/StatusRequest")
@dataclass
class StatusRequest:
    agent_id: str = ""

@wire_type("mission/StatusResponse")
@dataclass
class StatusResponse:
    agent_id: str = ""
    status: str = "idle"
    uptime_secs: int = 0

@wire_type("mission/LogEntry")
@dataclass
class LogEntry:
    timestamp: float = 0.0
    level: str = "info"
    message: str = ""
    agent_id: str = ""

@wire_type("mission/SubmitLogResult")
@dataclass
class SubmitLogResult:
    accepted: bool = True

@wire_type("mission/TailRequest")
@dataclass
class TailRequest:
    agent_id: str = ""
    level: str = "info"

@wire_type("mission/MetricPoint")
@dataclass
class MetricPoint:
    name: str = ""
    value: float = 0.0
    timestamp: float = 0.0
    tags: dict = field(default_factory=dict)

@wire_type("mission/IngestResult")
@dataclass
class IngestResult:
    accepted: int = 0
    dropped: int = 0

@wire_type("mission/Heartbeat")
@dataclass
class Heartbeat:
    agent_id: str = ""
    capabilities: list = field(default_factory=list)
    load_avg: float = 0.0

@wire_type("mission/Assignment")
@dataclass
class Assignment:
    task_id: str = ""
    command: str = ""

@wire_type("mission/Command")
@dataclass
class Command:
    command: str = ""

@wire_type("mission/CommandResult")
@dataclass
class CommandResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = -1

# ─────────────── Helpers ───────────────

_LEVEL_ORDER = {"debug": 0, "info": 1, "warn": 2, "error": 3, "fatal": 4}

def _level_rank(level: str) -> int:
    return _LEVEL_ORDER.get(level.lower(), 0)

# ─────────────── Services ───────────────

@service(name="MissionControl", version=1)
class MissionControl:
    def __init__(self):
        self._log_queue: asyncio.Queue[LogEntry] = asyncio.Queue()

    @rpc()
    async def getStatus(self, req: StatusRequest) -> StatusResponse:
        return StatusResponse(agent_id=req.agent_id, status="running", uptime_secs=3600)

    @rpc()
    async def submitLog(self, entry: LogEntry) -> SubmitLogResult:
        await self._log_queue.put(entry)
        return SubmitLogResult(accepted=True)

    @server_stream()
    async def tailLogs(self, req: TailRequest) -> AsyncIterator[LogEntry]:
        while True:
            entry = await self._log_queue.get()
            if req.agent_id and entry.agent_id != req.agent_id:
                continue
            if _level_rank(entry.level) < _level_rank(req.level):
                continue
            yield entry

    @client_stream()
    async def ingestMetrics(self, stream: AsyncIterator[MetricPoint]) -> IngestResult:
        accepted = 0
        async for point in stream:
            accepted += 1
        return IngestResult(accepted=accepted)

@service(name="AgentSession", version=1, scoped="session")
class AgentSession:
    def __init__(self, peer: str | None = None):
        self._peer = peer
        self._agent_id = ""
        self._capabilities = []

    @rpc()
    async def register(self, hb: Heartbeat) -> Assignment:
        self._agent_id = hb.agent_id
        self._capabilities = hb.capabilities
        if "gpu" in hb.capabilities:
            return Assignment(task_id="train-42", command="python train.py")
        return Assignment(task_id="idle", command="sleep 60")

    @bidi_stream()
    async def runCommand(self, commands: AsyncIterator[Command]) -> AsyncIterator[CommandResult]:
        async for cmd in commands:
            if cmd.command == "status":
                yield CommandResult(
                    stdout=f"Agent {self._agent_id}: ready", exit_code=0,
                )
            else:
                yield CommandResult(
                    stderr="Unknown demo command; use status", exit_code=1,
                )

# ─────────────── Main ───────────────

async def main():
    async with AsterServer(services=[MissionControl(), AgentSession], allow_all_consumers=True) as srv:
        print(srv.address)
        await srv.serve()

if __name__ == "__main__":
    asyncio.run(main())
