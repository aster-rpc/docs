import asyncio

from aster import AsterClient
from control import (
    AgentSession, Command, Heartbeat, LogEntry, MetricPoint,
    MissionControl, StatusRequest, TailRequest,
)


async def check_commands(agent, expected_name):
    async with agent.runCommand(timeout=10) as channel:
        await channel.send(Command(command="status"))
        response = await channel.recv()
        assert response.stdout == f"Agent {expected_name}: ready"
        assert response.exit_code == 0
        await channel.send(Command(command="unsupported"))
        response = await channel.recv()
        assert response.exit_code == 1


async def main():
    async with AsterClient() as client:
        control = await client.client(MissionControl)

        # One request produces one response.
        status = await control.getStatus(StatusRequest(agent_id="docs-check"))
        assert status.agent_id == "docs-check"

        # Submit one log, receive it through a server stream, then stop reading.
        await control.submitLog(LogEntry(
            timestamp=1.0, level="info", message="docs-log", agent_id="docs-check",
        ))
        events = control.tailLogs(TailRequest(agent_id="docs-check", level="info"))
        try:
            event = await anext(events)
            assert event.message == "docs-log"
        finally:
            await events.aclose()

        # Send three requests and receive the final upload count.
        async def metrics():
            for index in range(3):
                yield MetricPoint(name="cpu", value=float(index), timestamp=float(index))

        result = await control.ingestMetrics(metrics())
        assert result.accepted == 3

        # Two sessions retain separate worker registrations on one connection.
        first_session = await client.open_session(service_cls=AgentSession)
        async with first_session:
            first = await first_session.client(AgentSession)
            assignment = await first.register(Heartbeat(
                agent_id="docs-check", capabilities=["gpu"],
            ))
            assert assignment.task_id == "train-42"
            second_session = await client.open_session(service_cls=AgentSession)
            async with second_session:
                second = await second_session.client(AgentSession)
                await second.register(Heartbeat(agent_id="other-worker"))
                await check_commands(second, "other-worker")
                await check_commands(first, "docs-check")

    print("Passed: unary, server stream, client stream, bidi, and session isolation")


asyncio.run(main())
