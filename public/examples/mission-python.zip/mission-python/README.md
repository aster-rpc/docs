# MissionControl Python checkpoint

Use Python 3.10-3.13. Install the Python SDK using https://sdk.getaster.now/docs/quickstart/python/.
This project uses open development admission and in-memory state. The command
handler returns simulated results and never launches a host process.

Terminal 1 (activate the SDK environment):

    python control.py

Copy the complete address printed by the producer. In terminal 2, activate the
same environment, enter this directory, and run:

    ASTER_ENDPOINT_ADDR="<producer address>" python consumer.py

The consumer checks all four RPC patterns and two isolated sessions on one
connection, then prints its result. Stop the producer with Ctrl+C afterward.
This does not exercise CLI commands, enrollment or production authorization.
