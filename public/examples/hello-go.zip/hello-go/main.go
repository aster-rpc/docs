package main

import (
	"context"
	"fmt"
	aster "sdk.getaster.now/go"
	"time"
)

type Request struct{ Name string }

func (Request) AsterWireType() string { return "hello/Request" }

type Response struct{ Message string }

func (Response) AsterWireType() string { return "hello/Response" }

func run() error {
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	service := aster.NewService("Echo", 1,
		aster.Unary("hello", func(ctx context.Context, req *Request) (*Response, error) {
			return &Response{Message: "Hello, " + req.Name + "!"}, nil
		}),
		aster.ServerStream("greet", func(ctx context.Context, req *Request, send func(*Response) error) error {
			for i := 0; i < 3; i++ {
				if err := ctx.Err(); err != nil {
					return err
				}
				if err := send(&Response{Message: fmt.Sprintf("Hello, %s! (%d)", req.Name, i+1)}); err != nil {
					return err
				}
			}
			return nil
		}),
	)
	cfg := aster.AsterConfig{RelayMode: "disabled", BindAddr: "127.0.0.1:0", AllowAllConsumers: true}
	server, err := aster.StartServer(ctx, aster.ServerOptions{Config: cfg, Services: []*aster.Service{service}})
	if err != nil {
		return err
	}
	defer server.Close()
	client, err := aster.StartClient(ctx, cfg)
	if err != nil {
		return err
	}
	defer client.Close()
	if err := client.RegisterService(service); err != nil {
		return err
	}
	ticket, err := server.Ticket(ctx)
	if err != nil {
		return err
	}
	conn, err := client.ConnectTicket(ctx, ticket)
	if err != nil {
		return err
	}
	defer conn.Close()
	reply, err := aster.Call[Request, Response](ctx, conn, "Echo", "hello", &Request{Name: "Go"})
	if err != nil {
		return err
	}
	fmt.Println(reply.Message)
	for reply, err := range aster.CallServerStream[Request, Response](ctx, conn, "Echo", "greet", &Request{Name: "Go"}) {
		if err != nil {
			return err
		}
		fmt.Println(reply.Message)
	}
	return nil
}
func main() {
	if err := run(); err != nil {
		panic(err)
	}
}
