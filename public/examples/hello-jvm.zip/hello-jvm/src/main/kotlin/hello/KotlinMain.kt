package hello

import java.time.Duration
import java.util.concurrent.TimeUnit
import site.aster.client.AsterClient
import site.aster.client.CallOptions
import site.aster.codec.ForyCodec
import site.aster.codec.ForyTags
import site.aster.config.AsterConfig
import site.aster.server.AsterServer

fun main() {
    val config = AsterConfig.builder().relayMode("disabled")
        .bindAddr("127.0.0.1:0").allowAllConsumers(true).build()
    val codec = ForyCodec()
    ForyTags.register(codec.fory(), Echo.Request::class.java, "hello/Request")
    ForyTags.register(codec.fory(), Echo.Response::class.java, "hello/Response")
    AsterServer.builder().config(config).codec(codec).service(Echo(), EchoDispatcher())
        .build().get(15, TimeUnit.SECONDS).use { server ->
        AsterClient.builder().config(config).codec(codec).consumerAdmission(false)
            .build().get(15, TimeUnit.SECONDS).use { client ->
            val reply = client.call(server.node().nodeAddr(), "Echo", "hello",
                Echo.Request("Kotlin"), Echo.Response::class.java,
                CallOptions.DEFAULT.withTimeout(Duration.ofSeconds(5))).get()
            println(reply.message())
        }
    }
}
