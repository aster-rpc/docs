package hello;
import java.util.Map;
import site.aster.codec.Codec;
import site.aster.interceptors.CallContext;
import site.aster.server.spi.*;

// Released generators emit unary bodies. Supply streaming dispatch explicitly.
public final class EchoDispatcher implements ServiceDispatcher {
    private final ServiceDispatcher unary = new Echo$AsterDispatcher();
    public void registerTypes(org.apache.fory.Fory fory) { unary.registerTypes(fory); }
    public ServiceDescriptor descriptor() { return unary.descriptor(); }
    public Map<String, MethodDispatcher> methods() {
        return Map.of("hello", unary.methods().get("hello"), "greet", new Greet());
    }
    public Map<String, Class<?>> requestClasses() {
        return Map.of("hello", Echo.Request.class, "greet", Echo.Request.class);
    }
    public Map<String, Class<?>> responseClasses() {
        return Map.of("hello", Echo.Response.class, "greet", Echo.Response.class);
    }
    private static final class Greet implements ServerStreamDispatcher {
        public MethodDescriptor descriptor() {
            return new MethodDescriptor("greet", StreamingKind.SERVER_STREAM,
                RequestStyle.EXPLICIT, "hello/Request", java.util.List.of(),
                "hello/Response", false, false);
        }
        public void invoke(Object impl, byte[] payload, Codec codec,
                CallContext context, ResponseStream output) throws Exception {
            var request = (Echo.Request) codec.decode(payload, Echo.Request.class);
            for (int i = 1; i <= 3; i++) {
                if (context.isCancelled() || context.isExpired()) return;
                output.send(codec.encode(new Echo.Response("Hello, " + request.name() + "! (" + i + ")")));
            }
        }
    }
}
