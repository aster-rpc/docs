package hello;
import site.aster.annotations.*;
@Service(name = "Echo", version = 1)
public final class Echo {
    @WireType("hello/Request") public record Request(String name) {}
    @WireType("hello/Response") public record Response(String message) {}
    @Rpc public Response hello(Request request) {
        return new Response("Hello, " + request.name() + "!");
    }
}
