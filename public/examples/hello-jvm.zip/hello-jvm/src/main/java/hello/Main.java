package hello;
import java.util.concurrent.TimeUnit;
import site.aster.client.AsterClient;
import site.aster.client.CallOptions;
import site.aster.codec.ForyCodec;
import site.aster.codec.ForyTags;
import site.aster.config.AsterConfig;
import site.aster.server.AsterServer;

public final class Main {
    public static void main(String[] args) throws Exception {
        var config = AsterConfig.builder().relayMode("disabled")
            .bindAddr("127.0.0.1:0").allowAllConsumers(true).build();
        var codec = new ForyCodec();
        ForyTags.register(codec.fory(), Echo.Request.class, "hello/Request");
        ForyTags.register(codec.fory(), Echo.Response.class, "hello/Response");
        try (var server = AsterServer.builder().config(config).codec(codec).service(new Echo(), new EchoDispatcher()).build().get(15, TimeUnit.SECONDS);
             var client = AsterClient.builder().config(config).codec(codec)
                 .consumerAdmission(false).build().get(15, TimeUnit.SECONDS)) {
            var reply = client.call(server.node().nodeAddr(), "Echo", "hello",
                new Echo.Request("Java"), Echo.Response.class,
                CallOptions.DEFAULT.withTimeout(java.time.Duration.ofSeconds(5))).get(10, TimeUnit.SECONDS);
            System.out.println(reply.message());
            try (var stream = client.openServerStream(server.node().nodeAddr(), "Echo", "greet",
                    new Echo.Request("Java"), Echo.Response.class,
                    CallOptions.DEFAULT.withTimeout(java.time.Duration.ofSeconds(5))).get()) {
                Echo.Response item;
                while ((item = stream.recv()) != null) System.out.println(item.message());
            }
        }
    }
}
