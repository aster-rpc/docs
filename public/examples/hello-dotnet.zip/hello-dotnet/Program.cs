using Aster;
using Aster.Rpc;
using Apache.Fory;

var service = ServiceDefinition.Create("Echo", 1)
    .Unary<Request, Response>("hello", (req, ctx) =>
        ValueTask.FromResult(new Response { Message = $"Hello, {req.Name}!" }))
    .ServerStream<Request, Response>("greet", Greet)
    .Build();
var config = new AsterConfig { RelayMode = "disabled", BindAddr = "127.0.0.1:0" };
await using var server = await AsterServer.StartAsync(new AsterServerOptions {
    Config = config with { AllowAllConsumers = true }, Services = { service }
});
await using var client = await AsterClient.StartAsync(config);
client.RegisterTypes(service);
using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
await using var connection = await client.ConnectAsync(await server.TicketAsync(), timeout.Token);
var reply = await connection.UnaryAsync<Request, Response>("Echo", "hello",
    new Request { Name = ".NET" }, cancellationToken: timeout.Token);
Console.WriteLine(reply.Message);
await foreach (var item in connection.ServerStreamAsync<Request, Response>("Echo", "greet",
    new Request { Name = ".NET" }, cancellationToken: timeout.Token)) {
    Console.WriteLine(item.Message);
}

static async IAsyncEnumerable<Response> Greet(Request request, ServerCallContext context) {
    for (int i = 1; i <= 3; i++) {
        context.CancellationToken.ThrowIfCancellationRequested();
        yield return new Response { Message = $"Hello, {request.Name}! ({i})" };
        await Task.Yield();
    }
}
[ForyStruct, WireType("hello/Request")]
public sealed class Request { public string Name { get; set; } = ""; }
[ForyStruct, WireType("hello/Response")]
public sealed class Response { public string Message { get; set; } = ""; }
